package com.jts.movie.enums;

public enum Genre {
    DRAMA,
    THRILLER,
    ACTION,
    ROMANTIC,
    COMEDY,
    HISTORICAL,
    ANIMATION,
    SPORTS,
    SOCIAL,
    WAR
}
