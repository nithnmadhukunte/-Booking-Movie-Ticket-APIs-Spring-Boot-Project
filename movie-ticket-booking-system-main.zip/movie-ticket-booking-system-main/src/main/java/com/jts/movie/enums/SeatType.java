package com.jts.movie.enums;

public enum SeatType {
    CLASSIC,
    PREMIUM
}
