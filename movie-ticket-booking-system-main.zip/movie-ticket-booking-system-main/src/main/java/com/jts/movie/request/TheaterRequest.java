package com.jts.movie.request;

import lombok.Data;

@Data
public class TheaterRequest {

    private String name;
    private String address;
}
