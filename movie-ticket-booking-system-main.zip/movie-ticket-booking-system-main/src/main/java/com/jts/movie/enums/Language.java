package com.jts.movie.enums;

public enum Language {
    HINDI,
    ENGLISH,
    TELUGU,
    TAMIL,
    MARATHI,
    PUNJAB,
    KANNADA
}
