package com.jts.movie.enums;

public enum Gender {
    MALE,
    FEMALE,
    OTHER
}
